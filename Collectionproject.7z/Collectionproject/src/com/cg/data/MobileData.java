package com.cg.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.cg.bean.Account;


public class MobileData {
static Map<String,Account>data;
ArrayList<Account> list;
public MobileData(){
	data=new TreeMap<String,Account>();
	list=new ArrayList<Account>();
	list.add(new Account("prepaid","ram",300));
	list.add(new Account("prepaid","sri",200));
	list.add(new Account("prepaid","vijay",400));
	
	//data=new HashMap<String,Account>();
	data.put("1111111111",new Account("prepaid","ram",300));
	data.put("2222222222",new Account("prepaid","sri",200));
	data.put("3333333333",new Account("prepaid","vijay",500));
	data.put("4444444444",new Account("prepaid","uday",400));

for(Account a : list){
	System.out.println(a.getAccounttype()+""+a.getCustomername()+""+a.getAccountbalance());
}

Collections.sort(list);
System.out.println("after sorting:");
for(Account m : list){
	System.out.println(m.getAccounttype()+" "+m.getCustomername()+" "+m.getAccountbalance());
}
System.out.println();
}
public static Account getAccountDetails(String MobileNo){
	Account acc= data.get(MobileNo);
	return acc;
} 
public static double getviewBalance(String MobileNo){
	Account acc= data.get(MobileNo);
	return acc.getAccountbalance();
} 
}
