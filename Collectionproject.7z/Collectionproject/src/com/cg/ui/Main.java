package com.cg.ui;
import java.io.ObjectInputStream.GetField;
import java.util.Scanner;

import com.cg.Exception.MobileException;
import com.cg.Validation.Validation;
import com.cg.bean.Account;
import com.cg.data.MobileData;


public class Main {
	static Scanner sc;
	static MobileData md;
public static void main(String[] args)throws MobileException {
	
	
	System.out.println("*****MENU*****");
	System.out.println("1.Account Balaance Enquiry");
	System.out.println("2.recharge amount");
	System.out.println("3.Exit");
	
	sc=new Scanner(System.in);
	int input=sc.nextInt();
	switch(input)
	{
	case 1:
		AccountDetails();
		break;
	case 2:
		break;
	case 3:
		System.exit(0);
	}
}
	public static void AccountDetails() throws MobileException{
		System.out.println("1.Enter Mobile number to get Balance");
		sc = new Scanner(System.in);
		String MobileNo=sc.next();
	    Validation v=new Validation();
		v.Validateatype(MobileNo);
		if(v.Validateatype(MobileNo))
		{
			Account acc=getAccountDetails(MobileNo);
			double acc1=getviewBalance(MobileNo);
			System.out.println(acc);
			System.out.println(acc1);
		}
		else
		{
			throw new MobileException();
		}
	}
	public static Account getAccountDetails(String MobileNo){
		Account acc;
		md = new MobileData();
		acc=md.getAccountDetails(MobileNo);
		return acc;
	}
	public static double getviewBalance(String MobileNo){
		double acc1;
		md = new MobileData();
		acc1=md.getviewBalance(MobileNo);
		return acc1;
	
	}
}

