package com.cg.Exception;

public class MobileException extends  Exception{

	public MobileException() {
		super();
		// TODO Auto-generated constructor stub
	} 

}
