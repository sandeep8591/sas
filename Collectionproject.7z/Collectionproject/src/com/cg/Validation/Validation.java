package com.cg.Validation;

	import java.util.regex.Matcher;
import java.util.regex.Pattern;


	public class Validation{
			
			public boolean Validateatype(String MobileNo){
			Pattern p=Pattern.compile("[0-9]{10}");
				Matcher m=p.matcher(MobileNo);
			if(m.matches()){
				return true;
			}
			return false;
			}


	}

		
