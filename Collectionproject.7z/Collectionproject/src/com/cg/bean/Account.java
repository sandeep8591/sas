package com.cg.bean;

import java.util.Comparator;

public class Account implements Comparable<Account>{
private String accounttype;
private String customername;
private double accountbalance;

public Account(String accounttype, String customername, double accountbalance) {
	super();
	this.accounttype = accounttype;
	this.customername = customername;
	this.accountbalance = accountbalance;
}
public String getAccounttype() {
	return accounttype;
}
public void setAccounttype(String accounttype) {
	this.accounttype = accounttype;
}
public String getCustomername() {
	return customername;
}
public void setCustomername(String customername) {
	this.customername = customername;
}
public double getAccountbalance() {
	return accountbalance;
}
public void setAccountbalance(double accountbalance) {
	this.accountbalance = accountbalance;
}
@Override
public String toString() {
	return "Account [accounttype=" + accounttype + ", customername="
			+ customername + ", accountbalance=" + accountbalance + "]";
}
@Override
public int compareTo(Account m) {
	// TODO Auto-generated method stub
	return (int) (this.accountbalance-m.accountbalance);
}


}
