package dao;

import java.util.HashMap;
import java.util.Map;

import beans.Customer;
import beans.Mobile;

public class DaoMobile {
	Map<Integer,Mobile>hm=new HashMap<Integer,Mobile>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	public void addMobile(int mobile_id,Mobile mobile){
		hm.put(mobile_id, mobile);
	}
	public Map<Integer,Mobile> displayStock() {
		return hm;
	}
	public Map<Integer,Customer> addCustomer(Customer c) {
		hmc.put(c.getcustomer_id(), c);
		return hmc;
	}
}
