package beans;

public class Customer extends Mobile {
	String cust_name;
	String cust_address;
	String cellNo;
	int mobile_id;
	public Customer(){
		//customer_id++;
	}
	public void setmobile_id(int mobile_id){
		this.mobile_id=mobile_id;
	}
	public int getmobile_id(){
		return mobile_id;
	}
	public String getCust_name() {
		return cust_name;
	}
	public void setCust_name(String cust_name) {
		this.cust_name = cust_name;
	}
	public int getcustomer_id() {
		return customer_id;
	}
	public void setcustomer_id(int customer_id) {
		this.customer_id = customer_id;
		customer_id++;
	}
	public String getCust_address() {
		return cust_address;
	}
	public void setCust_address(String cust_address) {
		this.cust_address = cust_address;
	}
	public String getCellNo() {
		return cellNo;
	}
	public void setCellNo(String cellNo) {
		this.cellNo = cellNo;
	}
	public String toString(){
		return "\nCustomer Name: "+cust_name+"\nCustomer Address: "+cust_address+"\nCustomer ID: "+customer_id+"\n";
	}
}
