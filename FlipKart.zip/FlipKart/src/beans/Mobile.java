package beans;

public class Mobile {
	int orderid;
	int customer_id=1000;
	int totalPriceWithGst;
	String mobileName;
	int mobile_id;
	public Mobile(){
		
	}
	public Mobile(int mobile_id, String mobileName, int totalPriceWithGst) {
		this.totalPriceWithGst = totalPriceWithGst+(totalPriceWithGst*12/100);
		this.mobileName = mobileName;
		this.mobile_id = mobile_id;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(int customer_id) {
		this.customer_id = customer_id;
	}
	public int getMobileID() {
		return mobile_id;
	}
	public String toString(){
		return "\nMobile Name: "+mobileName+"\nMobile Id: "+mobile_id+"\nPrice: "+totalPriceWithGst+"\n";
	}
}
