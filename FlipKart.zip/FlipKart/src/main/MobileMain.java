package main;

import java.util.Scanner;

import beans.Customer;
import beans.Mobile;
import service.serviceMobile;

public class MobileMain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		serviceMobile s=new serviceMobile();
		Mobile mobile=null;
		s.addMobile();
		System.out.println("Do you want to display available Mobiles...");
		s.displayStock();
		int i=0;
		int customer_id=1000;
		Customer []c=new Customer[100];
		while(true){
			customer_id++;
			c[i]=new Customer();
			c[i].setcustomer_id(customer_id);
			System.out.println("Do you want to place the Order???\nAdd Some Details\nEnter you name..");
			String cust_name=sc.next();
			c[i].setCust_name(cust_name);
			System.out.println("Enter address..");
			String cust_address=sc.next();
			c[i].setCust_address(cust_address);
			System.out.println("Enter the Phone Number");
			c[i].setCellNo(sc.next());
			System.out.println("Which Mobile you want to purchase??\nEnter MobileID..");
			int mobile_id=sc.nextInt();
			s.purchaseMobile(mobile_id,c[i]);
			s.Order(c[i].getcustomer_id());
			i++;
		}
	}
}
