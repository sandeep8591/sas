package service;

import java.util.HashMap;
import java.util.Map;

import beans.Customer;
import beans.Mobile;
import dao.DaoMobile;

public class serviceMobile {
	Mobile m=new Mobile();
	Map<Integer,Mobile>hm=new HashMap<Integer,Mobile>();
	Map<Integer,Customer>hmc=new HashMap<Integer,Customer>();
	DaoMobile dao=new DaoMobile();
	public void addMobile(){
		Mobile mobile=new Mobile(101,"Samsung A50",20000);
		dao.addMobile(mobile.getMobileID(), mobile);
		mobile=new Mobile(102,"Samsung A30",15000);
		dao.addMobile(mobile.getMobileID(), mobile);
		mobile=new Mobile(103,"Samsung A10",10000);
		dao.addMobile(mobile.getMobileID(), mobile);
		mobile =new Mobile(104,"Nokia 6",15000);
		dao.addMobile(mobile.getMobileID(), mobile);
		mobile =new Mobile(105,"Nokia 8",35000);
		dao.addMobile(mobile.getMobileID(), mobile);
	}
	public void displayStock(){
		hm=dao.displayStock();
		System.out.println(hm);
	}
	public void purchaseMobile(int m,Customer c){
		Mobile mobile=null;
		hmc=dao.addCustomer(c);
		for(Mobile mo:hm.values()){
			if(m==mo.getMobileID()){
				mobile=mo;
				System.out.println("Mobile Purchased Successfully Done");
				c.setmobile_id(m);
			}
		}
	}
	public void Order(int customerId){
		int mobileid=0;
		for(Customer c1:hmc.values()){
			if(c1.getcustomer_id()==customerId){
				mobileid=c1.getmobile_id();
				System.out.println(c1);
			}
		}
		for(Mobile m:hm.values()){
			if(m.getMobileID()==mobileid){
				System.out.println(m);
			}
		}
	}
}
