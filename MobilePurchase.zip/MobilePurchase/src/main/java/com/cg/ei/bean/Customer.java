package com.cg.ei.bean;

public class Customer {
	
	private int custId;
	private String custName;
	private String address;
	private String cellno;
	
	public int getCustId() {
		return custId;
	}
	
	public void setCustId(int custId) {
		this.custId = custId;
	}
	
	public String getCustName() {
		return custName;
	}
	
	public void setCustName(String custName) {
		this.custName = custName;
	}
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getCellno() {
		return cellno;
	}
	
	public void setCellno(String cellno) {
		this.cellno = cellno;
	}

	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", custName=" + custName + ", address=" + address + ", cellno=" + cellno
				+ "]";
	}
	
	
	
	
	
}
