package com.cg.ei.pl;

import java.util.Scanner;

import com.cg.ei.bean.*;
import com.cg.ei.service.*;

public class Shop implements Runnable {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		Shop s=new Shop();
		Thread t=new Thread(s);
		t.start();
		
		
		
	}
	public void run() {
		Scanner sc=new Scanner(System.in);

		Scanner scr=new Scanner(System.in);
		ServiceApplications sa=new ServiceApplications();
		 
		sa.addMobiles();
		System.out.println("\tModel\t\t\tPrice\tAvailable\n\t==========================================");
		sa.displayAvailableMobiles();
		Customer customer=new Customer();
		int custId=0;
		int key;
		String model;
		System.out.println("1.Buy\n2.Display order for Customer\n3.Add New Mobile\n4.Show all orders\n5.show all mobiles:");
		key=sc.nextInt();
		while(true) {
		switch (key) {
		case 1:
			System.out.println("Enter model: ");
			model=scr.nextLine();
			if(sa.getMobile(model)) {
				custId++;
				customer.setCustId(custId);
				System.out.println("Enter customer name, contact number, and address: ");
				customer.setCustName(sc.next());
				customer.setCellno(sc.next());
				customer.setAddress(sc.next());
				sa.purchasemobile(customer, model);
			}
			else
				System.out.println("OUT OF STOCK!");
			break;
		case 2://Display Customers order details
			System.out.println("Enter Customer ID: ");
			System.out.println(sa.orderDetails(sc.nextInt()));
			
			
			break;

		case 3://Add New Mobile
	
			break;

		case 4:	//SHOW ALL ORDERS
	
			break;

		case 5:
			System.out.println("\tModel\t\t\tPrice\tAvailable\n\t==========================================");
			sa.displayAvailableMobiles();

		default:
			break;
		}
		System.out.println("1.Buy\n2.Display order for Customer\n3.Add New Mobile\n4.Show all orders\n5.show all mobiles:");
		key=sc.nextInt();
		
	}
	
	
	
	
	
	
	
	}
}
