package com.cg.ei.DAO;

import java.util.*;

import com.cg.ei.bean.*;

public interface OrderDAO {

	
	Map<String,Mobile> mobiles=new HashMap<String,Mobile>();
	Map<Integer,Customer> customers=new HashMap<Integer,Customer>();
	Map<Integer,Order> orders=new HashMap<Integer,Order>();
	
	
	void purchasemobile(Customer c, Order o);
	void addMobiles(Mobile m);
	Order getpurchasedetails(int custId);
	Map<String,Mobile> displayAvailableMobiles();
	Map<Integer,Customer> customerDetails();
	Map<Integer,Order> orderDetails(int custId);
	
	Customer getCustomer(int custId);
	Order getOrder(int orderId,int custId);
	Mobile getMobile(String model);
	
	
}
