package com.cg.ei.bean;

public class Mobile {

	private String model;
	private int totalprice_GST;
	private int inStore;
	
	
	
	public Mobile(String model, int totalprice_GST, int inStore) {
		super();
		this.model = model;
		this.totalprice_GST = totalprice_GST;
		this.inStore = inStore;
	}

	public String getModel() {
		return model;
	}
	
	public void setModel(String model) {
		this.model = model;
	}
	
	public int getTotalprice_GST() {
		return totalprice_GST;
	}
	
	public void setTotalprice_GST(int totalprice_GST) {
		this.totalprice_GST = totalprice_GST;
	}
	
	public int getInStore() {
		return inStore;
	}
	
	public void setInStore(int inStore) {
		this.inStore = inStore;
	}

	@Override
	public String toString() {
		return "\t" + model + "\t\t" + totalprice_GST + "\t" + inStore;
	}
	
	
	
	
	
}
