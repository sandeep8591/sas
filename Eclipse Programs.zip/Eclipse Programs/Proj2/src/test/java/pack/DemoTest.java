package pack;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class DemoTest 
{
	
	@Test
	public void shouldReturnTrue()
	{
		Demo obj=new Demo();
		assertTrue(obj.getBoolean());
	}

}
