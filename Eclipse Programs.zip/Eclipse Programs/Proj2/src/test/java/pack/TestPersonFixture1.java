package pack;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assumptions.assumeTrue;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestPersonFixture1 
{
	
	@BeforeAll
	public static void setBeforeAllTests()
	{
		System.out.println("Execute once before all test methods in " + "this class");
	}
	
	@AfterAll
	public static void doAfterAllTests()
	{
		System.out.println("Executed after all test methods in this" + "class");
	}
	
	@BeforeEach
	public void setbeforetests()
	{
		System.out.println("Executes before each test method in this"+ "class");
	}
	
	@AfterEach
	public void doafterTests()
	{
		System.out.println("Executed after each test method");
	}
	
	@Test
	public void GetFullName()
	{
		System.out.println("from GetFullName()");
		Person1 per =new Person1("Robert","King");
		assertEquals("Robert King", per.getFullName());
	}
	
	@Test
	public void NullsInName()
	{
		System.out.println("from NullsInName");
		Person1 per1=new Person1(null,"King");
		assertNotNull("full name null", per1.getFullName());
		assertNotNull("First name null", per1.getFirstName());
	}
	
	
	@Test
	void trueAssumption()
	{
		Person1 per2=new Person1("Robert","King",5000);
		assumeTrue(per2.getSalary()>4000);
		
	}

}
