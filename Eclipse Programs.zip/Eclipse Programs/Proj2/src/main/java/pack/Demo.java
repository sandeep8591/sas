package pack;

public class Demo 
{
	public Boolean getBoolean()
	{
		
		return true;
		
	}

}