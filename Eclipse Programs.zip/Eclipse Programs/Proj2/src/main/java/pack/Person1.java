package pack;

public class Person1 
{
	
	private String firstName,lastName;
	private int salary;
	
	Person1()
	{
		
	}
	
	public Person1(String fname,String lname)
	{
		this.firstName=fname;
		this.lastName=lname;
	}
	
	public Person1(String fname,String lname,int salary)
	{
		this.firstName=fname;
		this.lastName=lname;
		this.salary=salary;
	}
	
	public String getFullName()
	{
		String first=this.firstName;
		String last=this.lastName;
		return first+ " "+last;		
	}
	
	public String getFirstName()
	{
		return this.firstName;
	}
	
	public String getLastName()
	{
		return this.lastName;
	}
	
	public int getSalary()
	{
		return this.salary;
	}
	
	public static void main(String[] args)
	{
		Person1 p=new Person1("a","b");
		
	}

}
