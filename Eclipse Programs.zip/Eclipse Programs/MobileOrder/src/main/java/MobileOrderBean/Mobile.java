package MobileOrderBean;

public class Mobile 
{

	int model_no;
	String model_name;
	double price;
	final int gst=12;
	public int getModel_no() 
	{
		return model_no;
	}
	public void setModel_no(int model_number)
	{
		this.model_no = model_number;
	}
	public String getModel_name() 
	{
		return model_name;
	}
	public void setModel_name(String model_name) 
	{
		this.model_name = model_name;
	}
	public double getPrice() 
	{
		return price;
	}
	public void setPrice(double price) 
	{
		price=price+(price*gst/100);
		this.price = price;
	}
	public String toString() 
	{
		return "Mobile Details: "+model_no+" "+model_name+" "+price;
	}
}
