package MobileOrderDao;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import MobileOrderBean.Customer;
import MobileOrderBean.Mobile;

public interface MobilePurchaseDaoInterface 
{
	Map<Integer,Mobile>hm=new ConcurrentHashMap<Integer,Mobile>();
	Map<Integer,Customer>hm1=new HashMap<Integer,Customer>();
	Map<Integer,Integer>hm3=new HashMap<Integer,Integer>();
	
	public void addNewMobile(Mobile mobile);
	public void addNewCustomer(int model_number,Customer cust);
	public void OrderDetails(Customer cust,int model_number);
	

}
