package MobileOrderDao;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import MobileOrderBean.Customer;
import MobileOrderBean.Mobile;

public class MobilePurchaseDao implements MobilePurchaseDaoInterface
{
	Map<Integer,Mobile>hm=new ConcurrentHashMap<Integer,Mobile>();
	Map<Integer,Customer>hm1=new HashMap<Integer,Customer>();
	Map<Integer,Integer>hm3=new HashMap<Integer,Integer>();

	public void addNewMobile(Mobile mobile) 
	{
		hm.put(mobile.getModel_no(), mobile);
	}

	public void addNewCustomer(int model_number,Customer cust) 
	{
		hm1.put(cust.getCustomer_id(),cust);
	}
	
	public void OrderDetails(Customer cust,int model_number) 
	{
		for(Mobile mo:hm.values()) 
		{
			if(mo.getModel_no()==model_number) 
			{
				System.out.println(cust);
				System.out.println(mo);
				hm.remove(model_number);
				System.out.println("OrderPlaced.");
				System.out.println(hm);
				break;
			}
			else 
			{
				System.out.println("Out Of Stock\n\n");
			}
		}
	}
}