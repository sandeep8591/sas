package MobileOrderMain;

import java.util.Scanner;

import MobileOrderBean.Customer;
import MobileOrderBean.Mobile;
import MobileOrderService.MobilePurchaseService;

public class MobileMain 
{

	public static void main(String[] args) 
	{
		MobilePurchaseService s=new MobilePurchaseService();
		Scanner sc=new Scanner(System.in);
		Customer cust=new Customer();
		double orderid=100;
		int customer_id=1002;
		System.out.println("How many mobile you want to add in collection???");
		int mobile_count=sc.nextInt();
		int model_number=1524;
		for(int i=0;i<mobile_count;i++) 
		{
			model_number++;
			Mobile []mbl=new Mobile[mobile_count];
			mbl[i]=new Mobile();
			mbl[i].setModel_no(model_number);
			System.out.println("Enter the Name Of Mobile..");
			String mbl_name=sc.next();
			mbl[i].setModel_name(mbl_name);
			System.out.println(model_number);
			System.out.println("Enter the price of Mobile??");
			int price=sc.nextInt();
			mbl[i].setPrice(price);
			s.addNewMobile(mbl[i]);
		}
		while(true) 
		{
			//Creating new customer
			orderid++;
			customer_id++;
			cust.setCustomer_id(customer_id);
			System.out.println("Do you want to place the order????\nGive Your Details First: ");
			System.out.println("Enter your Name: ");
			String custName=sc.next();
			cust.setCustomer_name(custName);
			System.out.println("Enter Your Address: ");
			String custAddress=sc.next();
			cust.setCustomer_address(custAddress);
			System.out.println("Enter your Phone Number: ");
			String phone_number=sc.next();
			cust.setPhone_number(phone_number);
			System.out.println("Customer Id: "+customer_id);
			System.out.println("Enter The model Number of Mobile : ");
			int model_number1=sc.nextInt();
			s.addNewCustomer(model_number1,cust);
			System.out.println("Confirm Order??");
			s.OrderDetail(cust, model_number1);
		}
	}

}


