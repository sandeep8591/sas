package MobileOrderService;

import MobileOrderBean.Customer;
import MobileOrderBean.Mobile;
import MobileOrderDao.MobilePurchaseDao;

public class MobilePurchaseService implements MobilePurchaseServiceInterface
{
	MobilePurchaseDao dao=new MobilePurchaseDao();

	public void addNewMobile(Mobile mobile) 
	{
		dao.addNewMobile(mobile);
	}

	public void addNewCustomer(int model_number1,Customer cust) 
	{
		dao.addNewCustomer(model_number1,cust);
	}

	public void OrderDetail(Customer cust,int model_number) 
	{
		dao.OrderDetails(cust, model_number);
	}

}
