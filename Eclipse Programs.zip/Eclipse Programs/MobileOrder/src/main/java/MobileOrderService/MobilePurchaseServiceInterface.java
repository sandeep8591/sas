package MobileOrderService;

import MobileOrderBean.Customer;
import MobileOrderBean.Mobile;
import MobileOrderDao.MobilePurchaseDao;

public interface MobilePurchaseServiceInterface 
{
	MobilePurchaseDao dao=new MobilePurchaseDao();
	
	public void addNewMobile(Mobile mobile);
	public void addNewCustomer(int model_number1,Customer cust);
	public void OrderDetail(Customer cust,int model_number);

}
