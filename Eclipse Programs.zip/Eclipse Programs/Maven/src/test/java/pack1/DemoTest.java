package pack1;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import pack.DemoClass;

class DemoTest {

	@Test
	void addTest()  
	{
		DemoClass obj=new DemoClass();
		assertEquals(7,obj.add(4,3));
	}

}
