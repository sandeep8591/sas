package pack;

public class DemoClass 
{
	public int add(int num1,int num2)
	{
		return num1+num2;
	}

	public static void main(String[] args) 
	{
		
		
	}

}
