package AccountBean;


public class BankAccount 
{
	private long acc_no,adhar_no,phone_no,balance,showBalance,deposit;
	String name;
	
	public long getDeposit() 
	{
		return deposit;
	}
	
	public void setDeposit(long deposit) 
	{
		this.deposit = deposit;
	}
	
	public long getShowBalance() 
	{
		return showBalance;
	}

	public void setShowBalance(long showBalance) 
	{
		this.showBalance = showBalance;
	}
	
	public long getAcc_no() 
	{
		return acc_no;
	}

	public void setAcc_no(long acc_no) 
	{
		this.acc_no = acc_no;
	}

	public long getAdhar_no() 
	{
		return adhar_no;
	}

	public void setAdhar_no(long adhar_no) 
	{
		this.adhar_no = adhar_no;
	}

	public long getPhone_no() 
	{
		return phone_no;
	}

	public void setPhone_no(long phone_no) 
	{
		this.phone_no = phone_no;
	}

	public long getBalance() 
	{
		return balance;
	}

	public void setBalance(long balance) 
	{
		this.balance = balance;
	}

	public String getName() 
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	@Override
	public String toString()
	{
		return "Account Details [ Name : " +name +", Account No. : " + acc_no + ", Aadhar No. : " + adhar_no +", Phone No. : " + phone_no + ", Balance : " + balance +"]\n";
	}
	
	
}
