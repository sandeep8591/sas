package AccountService;

import java.util.Map;
import java.util.Scanner;

import AccountMain.Main;
import AccountBean.BankAccount;
import AccountDao.AccountDao;

public class AccountService implements AccountServiceInterface
{
	AccountDao d=new AccountDao();
	long depo,bal;
	
	public void addNewAccount(BankAccount ba) 
	{
		d.addNewAccount(ba);
	}
	
	public void showBalance()
	{
		bal=depo;
	}
	
	public void deposit()
	{	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your account number : ");
		long a=sc.nextLong();
		
		System.out.println("Enter the amount you want to deposit : ");
		
		
		long depo=sc.nextLong();
		
		System.out.println(depo);
	}
	
	
	
	
	
	
	
	

	@Override
	public Map<Integer,BankAccount> displayDetails()
	{
		return d.displayDetails();
	}


}
