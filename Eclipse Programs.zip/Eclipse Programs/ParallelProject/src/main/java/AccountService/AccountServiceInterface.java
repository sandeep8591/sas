package AccountService;

import java.util.HashMap;
import java.util.Map;

import AccountBean.BankAccount;

public interface AccountServiceInterface 
{
	Map<Integer,BankAccount> ba = new HashMap<Integer,BankAccount>();
	
	void addNewAccount(BankAccount ba);
	
	void showBalance();
	void deposit();
	
	
	Map<Integer,BankAccount> displayDetails();
	
	
	

}
