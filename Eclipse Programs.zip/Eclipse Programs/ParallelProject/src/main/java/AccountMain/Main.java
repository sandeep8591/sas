package AccountMain;

import java.util.*;

import AccountBean.BankAccount;
import AccountService.AccountService;

public class Main 
{
	
	public static void main(String[] args) 
	{
		AccountService s=new AccountService();
		Scanner sc=new Scanner(System.in);
		
		long acc_no=987654000;
		
		try
		{
			while(true)
			{
				int choice;
				System.out.println("1.Create Account \n2.Show Balance \n3.Deposit \n4.Withdraw \n5.Fund Transfer \n6.Print Transactions \n7.Display Details \n\nEnter Choice :");
				choice=sc.nextInt();
				switch (choice)
				{
				case 1:
					BankAccount ba=new BankAccount();
					acc_no++;
					ba.setAcc_no(acc_no);
					System.out.println("Enter The Name Of Account Holder : ");
					ba.setName(sc.next());
					System.out.println("Enter Your Aadhar Card Number : ");
					ba.setAdhar_no(sc.nextInt());
					System.out.println("Enter Your Phone Number : ");
					ba.setPhone_no(sc.nextInt());
					System.out.println("Your Bank Account Number is " + acc_no + "\n");
					s.addNewAccount(ba);
					break;
					
				case 2:
					s.showBalance();
					
					
				case 3:
					s.deposit();
					
					
				case 4:
					
				case 5:
					
				case 6:
					
				case 7:
					System.out.println(s.displayDetails());
					break;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}

	}

}
