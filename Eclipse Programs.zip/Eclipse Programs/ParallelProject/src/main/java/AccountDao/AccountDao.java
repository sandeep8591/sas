package AccountDao;

import java.util.HashMap;
import java.util.Map;

import AccountBean.BankAccount;

public class AccountDao implements AccountDaoInterface
{

	public void addNewAccount(BankAccount ba) 
	{
		bas.put((int) ba.getAcc_no(), ba);
		
	}

	public void showBalance() 
	{

		
	}
	
	

	public void setDeposit() 
	{
		
		
	}
	
	public Map<Integer, BankAccount> displayDetails() 
	{
		
		return bas;
	}

	
	
}
