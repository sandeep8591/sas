package AccountDao;

import java.util.HashMap;
import java.util.Map;

import AccountBean.BankAccount;

public interface AccountDaoInterface 
{
	
	Map<Integer,BankAccount> bas = new HashMap<Integer,BankAccount>();
	
	void addNewAccount(BankAccount ba);
	void showBalance();
	void deposit();
	
	
	Map<Integer,BankAccount> displayDetails();

}
