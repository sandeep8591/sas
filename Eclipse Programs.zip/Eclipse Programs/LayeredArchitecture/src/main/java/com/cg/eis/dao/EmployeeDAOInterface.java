package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeDAOInterface 
{
	Map<Integer, Employee> emps = new HashMap<Integer, Employee>();
	
	void addNewEmployee(Employee emp);
	Employee findInsuranceScheme(int id);
	void setInsuranceScheme(String scheme,Employee emp);
	
	Map<Integer,Employee> displayDetails();
	String acknowledge();
}
