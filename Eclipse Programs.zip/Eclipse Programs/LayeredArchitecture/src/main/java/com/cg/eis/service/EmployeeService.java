package com.cg.eis.service;

import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAO;

public class EmployeeService implements  EmployeeServiceInterface
{
	EmployeeDAO d=new EmployeeDAO();
	
	public void addNewEmployee(Employee emp)
	{
		d.addNewEmployee(emp);
	}
	
	public void findInsuranceScheme(int id)
	{
		Employee emp=new Employee();
		emp=d.findInsuranceScheme(id);
		if(emp!=null)
		{
			if(emp.getSalary()>5000)
			{
				if(emp.getSalary()<20000 && emp.getDesignation().equals("System Associate"))
				{
					System.out.println("Eligible Insurance Scheme : \"Scheme C\"");
					d.setInsuranceScheme("Scheme C", emp);
				}
				if( emp.getSalary()>=20000 && emp.getSalary()<40000 )
				{	
					if( emp.getDesignation().equals("Programmer"))
				
				{
					System.out.println("Eligible Insurance Scheme : \"Scheme B\"");
					d.setInsuranceScheme("Scheme B", emp);
				}
				}
				else if(emp.getSalary()>=40000 && emp.getDesignation().equals("Manager"))
				{
					System.out.println("Eligible Insurance Scheme : \"Scheme A\"");
					d.setInsuranceScheme("Scheme A", emp);
				}
				else
				{
					System.out.println("No Scheme");
				}
			}
			else
			{
				System.out.println("No Scheme");
			}
		}
		else
		{
			System.out.println("Incorrect ID");
		}
	}
	
	public Map<Integer,Employee> displayDetails()
	{
		return d.displayDetails();
	}
	
}