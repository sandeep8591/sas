package com.cg.eis.dao;

import java.util.HashMap;
import java.util.Map;
import com.cg.eis.bean.Employee;

public class EmployeeDAO implements EmployeeDAOInterface
{
	
	public void addNewEmployee(Employee emp)
	{
		emps.put(emp.getId(), emp);
	}
	
	public Employee findInsuranceScheme(int id)
	{
		Employee emp=null;
		for(Employee o:emps.values())
		{
			if(o.getId()==id)
				emp=o;
		}
		return emp;
	}
	
	public Map<Integer,Employee> displayDetails()
	{
		return emps;
	}
		
	public void setInsuranceScheme(String scheme, Employee emp) 
	{
		for(Employee o:emps.values())
		{
			if(o.getId()==emp.getId())
			{
				o.setInsuranceSchema(scheme);
			}
		}
		
	}

	public String acknowledge() 
	{
		
		return "Operation Successfull";
	}

}