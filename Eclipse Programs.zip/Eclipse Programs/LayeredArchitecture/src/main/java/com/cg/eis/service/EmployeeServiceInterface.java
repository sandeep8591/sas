package com.cg.eis.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeServiceInterface 
{

	Map<Integer,Employee> emp = new HashMap<Integer,Employee>();
	
	void addNewEmployee(Employee emp);
	void findInsuranceScheme(int id);
	Map<Integer,Employee> displayDetails();
	
}