package com.cg.eis.pl;

import java.util.*;

import com.cg.eis.bean.Employee;
import com.cg.eis.dao.EmployeeDAOInterface;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceInterface;

public class MainClass 
{

	public static void main(String[] args) throws Exception
	{
		
		EmployeeService s=new EmployeeService();
		Scanner sc=new Scanner(System.in);
		Scanner Str=new Scanner(System.in);
		int choice,id=0;
		
		try
		{
			while(true)
			{
				System.out.println("1.Insert \n2.Insurance Scheme \n3.Display \nEnter Choice : ");
				choice=sc.nextInt();
				switch (choice)
				{
				case 1:
					Employee emp=new Employee();
					id++;
					emp.setId(id);
					System.out.println("Enter Name of Employee : ");
					emp.setName(sc.next());
					System.out.println("Enter Designation : ");
					emp.setDesignation(Str.nextLine());
					System.out.println("Enter Salary : ");
					emp.setSalary(sc.nextInt());
					
					System.out.println("Your ID is "+id);
					s.addNewEmployee(emp);
					break;
				
				case 2:
					
					System.out.println("Enter your ID : ");
					s.findInsuranceScheme(sc.nextInt());
					break;
					
				case 3:
					System.out.println(s.displayDetails());
					break;
					
				default:
					System.exit(0);
					break;
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}