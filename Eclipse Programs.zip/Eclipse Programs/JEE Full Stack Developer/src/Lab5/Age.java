package Lab5;

import java.util.Scanner;

class ArithmeticException extends Exception
{
	
}

public class Age extends Exception
{
	public void check()
	{
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Age");
		int age=sc.nextInt();
		try {
		if(age<15)
			throw new ArithmeticException();
		
		
		else
			System.out.println("Logged IN");
		}
	catch(ArithmeticException e)
	{
		System.out.println("You Can't Logged IN");
	}
	
	}
	public static void main(String[] args) 
	{
		Age a=new Age();
		a.check();

	}

}
