package Lab5;

import java.util.Scanner;

class FirstNameException extends Exception
{
	public String toString()
	{
		return "Enter First Name....";
	}
}

class LastNameException extends Exception
{
	public String toString()
	{
		return "Enter Last Name....";
	}
}

public class ValidName
{

	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("First Name : ");
		String first=sc.nextLine();
		System.out.println("Last Name : ");
		String last=sc.nextLine();
		try
		{
			if(first.isEmpty())
			{
				throw new FirstNameException();
			}
			if(last.isEmpty())
			{
				throw new LastNameException();
			}
		}
		catch(FirstNameException e)
		{
			System.out.println(e);
		}
		catch(LastNameException l)
		{
			System.out.println(l);
		}
	}
}
