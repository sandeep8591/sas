package Project;
import java.util.*;

public class CollectionsDemo 
{
	

	public static void main(String[] args) 
	{
		
		HashSet<String> s1=new HashSet<String>();
		//HashSet s1=new HashSet();
		s1.add("Beginner");
		s1.add("Java");
		s1.add("Java");
		s1.add("Tutorial");
		System.out.println("Elements of HashSet : "+s1);
		System.out.println("Elements of HashSet has string : "+s1.contains("Java"));
		
		//TreeSet t1=new TreeSet(s1);
		TreeSet<String> t1=new TreeSet<String>(s1);
		System.out.println("t1.equals s1 : "+t1.equals(s1));
		
		Iterator<String> itr=t1.iterator();
		System.out.println("Iteration Type 1 : ");
		while(itr.hasNext())
		{
			String e=(String)itr.next();
			System.out.println(e);
		}
		System.out.println("Iteration Type 2 : ");
		for(Object o: t1)
		{
			System.out.println(o);
		}
		
		/*Object[] a=s1.toArray();
		 System.out.println("After converting to Array : ");
		 
		 */

	}

}
