package Project;
import Project.Emp;
import java.util.*;
public class TestEmp 
{

	public static void main(String[] args) 
	{
		Emp e1=new Emp(1,"MSD");
		Emp e2=new Emp(1,"MSD");
		Emp e3=new Emp(2,"Virat");
		System.out.println(e1.equals(e2));
		
		/* Hashset<Emp> hs=new Hashset<Emp>();
		 * 
		 * hs.add(e1);
		 * hs.add(e2);
		 * hs.add(e3);
		 */
	}

}
