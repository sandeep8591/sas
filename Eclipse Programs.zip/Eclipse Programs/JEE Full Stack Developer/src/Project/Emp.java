package Project;
import java.util.*;

public class Emp 
{
	private int empid;
	String name;
	public Emp(int empid,String name)
	{
		this.empid=empid;
		this.name=name;
	}
	
	/*public int hashCode()
	 * {
	 * 		return 12;
	 * }
	 * 
	 * public boolean equals(Object obj)
	 * {
	 * 		System.out.println("in");
	 * 		boolean flag=false;
	 * 		Emp e=(Emp)obj;
	 * 			
	 * 		if ((this.empid==e.empid) && (this.name)).equals(e.name))
	 * 		{
	 * 			flag=true;
	 * 			return flag;
	 * 		}
	 * 
	 * }
	 */
	
	
	public static void main(String[] args) 
	{
		
		//Exception e1=new Exception();
		//Exception e2=new Exception();
		
		
		
	}

}
