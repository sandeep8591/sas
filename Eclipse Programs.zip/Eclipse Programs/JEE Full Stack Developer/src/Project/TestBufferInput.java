package Project;
import java.io.*;

public class TestBufferInput 
{
	
	public static void main(String[] args)
	{
		byte buffer[]=new byte[555];
		
		try
		{
			BufferedInputStream bis=new BufferedInputStream(new FileInputStream("text1.txt"));
			bis.read(buffer);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		String s = new String(buffer);
		System.out.println(s.trim());
	}

}
