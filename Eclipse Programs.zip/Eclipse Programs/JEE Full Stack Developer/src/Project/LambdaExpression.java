package Project;


interface Transaction
{
	void withdraw(int amt);
}

public class LambdaExpression 
{
	
	

	public static void main(String[] args) 
	{
		Transaction obj=(int amt)->System.out.println("Amount : "+amt);
		
		obj.withdraw(900);
	}

}
