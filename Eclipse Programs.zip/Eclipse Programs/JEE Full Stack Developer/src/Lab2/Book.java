package Lab2;

public class Book extends WrittenItem
{
	String book;
	public Book()
	{
		super();
		//System.out.println("Default");
	}
	

}
