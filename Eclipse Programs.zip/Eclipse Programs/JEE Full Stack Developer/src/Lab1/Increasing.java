package Lab1;

import java.util.Scanner;

public class Increasing 
{
	public boolean checkNumber(int n)
	{
		int a,b,cnt=0;
		while(n!=0)
		{
			a=n%10;
			n=n/10;
			b=n%10;
			if(a<b) 
			{
				cnt++;
			}
		}	
		if(cnt>0)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	public static void main(String[] args) 
	{
		int n;
		boolean ch;
		System.out.println("Enter the number : ");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		Increasing i=new Increasing();
		ch=i.checkNumber(n);
		if(ch==true)
		{
			System.out.println("Increasing");
		}
		else
		{
			System.out.println("Not Increasing");
		}
	}

}
