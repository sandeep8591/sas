package Lab1;
import java.util.*;

public class PowerOf2 
{
	public boolean checkNumber(int n)
	{
	int sum=1,cnt=0;
	for(int i=1;i<=n;i++)
	{
		sum=sum*2;
		if(sum==n)
		{
			cnt++;
		}
	}
	if(cnt>0)
	{
		return true;
	}
	else
	{
		return false;
	}
	}
	public static void main(String[] args) 
	{
		int n;
		boolean ch;
		System.out.println("Enter the number : ");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		PowerOf2 i=new PowerOf2();
		ch=i.checkNumber(n);
		if(ch==true)
		{
			System.out.println("Power of 2 ");
		}
		else
		{
			System.out.println("Not Power of 2 ");
		}
	}

}
