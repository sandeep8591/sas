package Lab8;
import java.util.*;

public class PositiveString 
{
	public boolean PositiveString1()
	{
		String str;
		Character c1,c2;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter String :");
		str=sc.next();
		char[] arr=str.toCharArray();
		
	 
	 
		for(int i=0;i<arr.length;i++)
		{
			for(int j=i;j<arr.length;j++)
			{
				
				if(Character.toUpperCase(arr[i])>Character.toUpperCase(arr[j]))
				{
					return false;
				}	
			}
		}
		return true;
	}

	public static void main(String[] args) 
	{
		PositiveString p=new PositiveString();
		boolean b=p.PositiveString1();
		if(b==true)
		{
			System.out.println("Positive String");
		}
		else
		{
			System.out.println("Negative String");
		}
		
		

	}

}
