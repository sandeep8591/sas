package Lab8;
import java.io.*;

public class FileCheck 
{

	public static void main(String[] args) 
	{
		File f=new File("text.txt");
		byte b=(byte) f.length();
		System.out.println(b);
		if(f.canRead())
		{
			System.out.println("Readable");
		}
		else
		{
			System.out.println("Not Readable");
		}
		if(f.canWrite())
		{
			System.out.println("Writable");
		}
		else
		{
			System.out.println("Not Writable");
		}
	}

}
