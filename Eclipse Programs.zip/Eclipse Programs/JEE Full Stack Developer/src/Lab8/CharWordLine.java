package Lab8;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CharWordLine 
{
	public void linecheck() throws IOException
	{
		String line=" ";
		int cnt=1;
		try
		{
			FileReader file=new FileReader("text.txt");
			BufferedReader b=new BufferedReader(file);
			boolean eof=false;
			while(eof==false)
			{
				line=b.readLine();
				if(line!=null)
				{
					cnt++;
				}
				else
				{
					eof=true;
				}
			}
			cnt=cnt-1;
			System.out.println("Line Count : " + cnt);
			b.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	
	public void charcheck() throws IOException
	{
		String line=" ";
		int count=0,sum=0;
		try
		{
			FileReader file=new FileReader("text.txt");
			BufferedReader b=new BufferedReader(file);
			boolean eof=false;
			while(eof==false)
			{
				line=b.readLine();
				if(line!=null)
				{
					String[] wordList=line.split("\\s+");
					count=wordList.length;
					sum=sum+count;
					count=sum;
				}
				else
				{
					eof=true;
				}
			}
			
			System.out.println("Word Count : " +sum);
			b.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	public void alphacheck() throws IOException
	{
		String line=" ";
		int count1=0;
		try
		{
			FileReader file=new FileReader("text.txt");
			BufferedReader b=new BufferedReader(file);
			boolean eof=false;
			while(eof==false)
			{
				line=b.readLine();
				if(line!=null)
				{
					count1+=line.length();
				}
				else
				{
					eof=true;
				}
			}
			
			System.out.println("Alphabet Count : " + count1);
			b.close();
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) throws IOException
	{
		
		CharWordLine c=new CharWordLine();
		c.alphacheck();
		c.charcheck();
		c.linecheck();
	}

}
