package Lab8;

import java.util.*;

public class ValidateUser 
{
	public boolean check()
	{
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name : ");
		s=sc.next();
		char arr[]=s.toCharArray();
		if(arr.length>=12) 
		{
		if(arr[arr.length-1]=='b')
		{
			if(arr[arr.length-2]=='o')
			{
				if(arr[arr.length-3]=='j')
				{
					if(arr[arr.length-4]=='_')
					{
						return true;
					}
				}
			}
		}
		}
		return false;
	}
	
	public static void main(String[] args) 
	{
		ValidateUser e=new ValidateUser();
		boolean b=e.check();
		if(b==true)
		{
			System.out.println("Correct");
		}
		else
		{
			System.out.println("Incorrect");
		}
	}

}
