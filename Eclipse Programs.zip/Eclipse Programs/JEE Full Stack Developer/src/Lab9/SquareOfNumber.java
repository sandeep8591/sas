package Lab9;

import java.util.HashMap;
import java.util.Scanner;

public class SquareOfNumber 
{

	public HashMap getSqaures() 
	{

		int []arr= {2,5,4,6,7};
		int sqr;
		Scanner sc=new Scanner(System.in);
		HashMap<Integer,Integer> hashMap=new HashMap<Integer,Integer>();
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		System.out.println("Enter the no. of element you want : ");
		int n=sc.nextInt();
		System.out.println("Enter the integer array : ");
		for(int i=0;i<n;i++)
		{
			arr[i]=sc.nextInt();
		}
		for(int i=0;i<n;i++) 
		{
			sqr=arr[i]*arr[i];
			hashMap.put(arr[i],sqr);
		}
		hm.putAll(hashMap);
		return hm;
	}

	public static void main(String[] args) 
	{

		HashMap h;
		SquareOfNumber s=new SquareOfNumber();
		h=s.getSqaures();
		System.out.println(h);
	}
}
