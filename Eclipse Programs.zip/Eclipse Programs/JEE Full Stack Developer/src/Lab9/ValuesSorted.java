package Lab9;
import java.util.*;

public class ValuesSorted 
{
	
	public void getValues()
	{
			HashMap<String, Integer> hm=new HashMap<String,Integer>();
			HashMap<String, Integer> hm1=new HashMap<String,Integer>();
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter How many pairs you want to create?");
			int n=sc.nextInt();
			String[] str=new String[n];
			Integer[] val=new Integer[n];
			for(int i=0;i<n;i++)
			{
				System.out.println("Enter the Key : ");
				str[i]=sc.next();
				System.out.println("Enter the Value : ");
				val[i]=sc.nextInt();
				hm.put(str[i],val[i]);
			}
			hm1.putAll(hm);
			TreeMap<String,Integer> treeMap=new TreeMap<String,Integer>();
			SortedSet<Integer> m=new TreeSet<Integer>(hm.values());
			System.out.println("Sorted List : "+m);
		
		}


	public static void main(String[] args) 
	{
		ValuesSorted v=new ValuesSorted();
		v.getValues();
	}
}
