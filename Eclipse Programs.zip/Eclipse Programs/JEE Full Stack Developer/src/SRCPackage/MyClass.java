package SRCPackage;

public class MyClass 
{
	
	public int add(int a,int b)
	{
		return a+b;
	}
	
	public String concat(String a,String b)
	{
		return a+b;
	}

	

}
