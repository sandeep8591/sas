package SRCPackage;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MyTest 
{
	MyClass obj=new MyClass();
	
	@Test
	void addTest()
	{
		int res=obj.add(5, 3);
		assertEquals(8, res);  
	}
	
	@Test
	void concatTest()
	{
		String res=obj.concat("Hello", "World");
		assertEquals("HelloWorld", res);
	}

}
