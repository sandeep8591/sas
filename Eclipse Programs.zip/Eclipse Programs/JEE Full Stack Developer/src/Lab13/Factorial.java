package Lab13;
import java.util.*;
import java.util.function.*;

public class Factorial 
{
	static int fact(int num)
	{
		int res=1;
		for(int i=1;i<=num;i++)
		{
			res=res*i;
		}
		
		return res;
	}

	public static void main(String[] args) 
	{
		Function<Integer,Integer> f= Factorial :: fact;
		System.out.println("Factorial : "+f.apply(5));
		
	}

}
