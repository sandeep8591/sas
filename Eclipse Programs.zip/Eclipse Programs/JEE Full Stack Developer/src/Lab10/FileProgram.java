package Lab10;

import java.io.BufferedReader;
import java.util.*;

public class FileProgram 
{

	public static void main(String args[])
	{
		BufferedReader in= null;
		BufferedReader out= null;
		CopyDataThread obj= new CopyDataThread(in,out);
		Thread t1= new Thread(obj);
		t1.start();
	}
}