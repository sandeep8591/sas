package Lab10;
import java.time.LocalDateTime;


public class Timer implements Runnable
{
	public void run()
	{
		try
		{
			while(true)
			{
				LocalDateTime n=LocalDateTime.now();
				System.out.println(n);
				Thread.sleep(10000);
			}
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

	public static void main(String[] args) 
	{
		Timer t=new Timer();
		Thread t1=new Thread(t);
		t1.start();

	}

}
