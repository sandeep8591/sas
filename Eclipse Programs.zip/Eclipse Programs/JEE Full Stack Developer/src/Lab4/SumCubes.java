package Lab4;

import java.util.*;

public class SumCubes 
{
	public void calculation()
	{
		int n,rem,sum=0;
		System.out.println("Enter the number : ");
		Scanner sc=new Scanner(System.in);
		n=sc.nextInt();
		while(n!=0)
		{
			rem=n%10;
			n=n/10;
			sum=sum+(rem*rem*rem);
		}
		System.out.println(sum);
	}
	
	public static void main(String[] args) 
	{
		SumCubes s=new SumCubes();
		s.calculation();
	}

}
