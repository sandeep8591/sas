package groupID.BankingPay.com.cg.eis.bean;

import java.time.LocalDateTime;
public class Account {
	double account_Number;
	String account_HolderName;
	int phone_Number;
	int balance;
	int aadhar_number;
	int deposit_amount;
	LocalDateTime date;
	public LocalDateTime getDate() {
		return date;
	}
	public void setDate(LocalDateTime date) {
		this.date = date;
	}
	public int getDeposit_amount() {
		return deposit_amount;
	}
	public void setDeposit_amount(int deposit_amount) {
		this.deposit_amount = deposit_amount;
	}
	public double getAccount_Number() {
		return account_Number;
	}
	public void setAccount_Number(double account_Number) {
		this.account_Number = account_Number;
	}
	public String getAccount_HolderName() {
		return account_HolderName;
	}
	public void setAccount_HolderName(String account_HolderName) {
		this.account_HolderName = account_HolderName;
	}
	public double getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(int phone_Number) {
		this.phone_Number = phone_Number;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public double getAadhar_number() {
		return aadhar_number;
	}
	public void setAadhar_number(int aadhar_number) {
		this.aadhar_number = aadhar_number;
	}
	public String toString() {
		return account_Number+" "+account_HolderName+" "+" "+phone_Number+" "+aadhar_number+" "+balance;
	}
}
