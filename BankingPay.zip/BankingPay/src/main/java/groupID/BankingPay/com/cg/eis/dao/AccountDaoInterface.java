package groupID.BankingPay.com.cg.eis.dao;

import java.util.Map;

import groupID.BankingPay.com.cg.eis.bean.Account;

public interface AccountDaoInterface {
	public Map<Double, Account> displayAccountDetails();
	public void addNewAccount(Account account);
}
