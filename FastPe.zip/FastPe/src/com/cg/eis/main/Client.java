package com.cg.eis.main;

import java.time.LocalDateTime;
import java.util.Scanner;

import com.cg.eis.bean.Account;
import com.cg.eis.bean.History;
import com.cg.eis.service.AccountService;

public class Client {

	public static void main(String[] args) {
		AccountService as=new AccountService();
		int i;
		as.addAccIntoMap();
		Scanner sc=new Scanner(System.in);
		while(true) {
		System.out.println("Do you had Account??\t Press 1\nDo you want to create account??\tPress 2");
		int n=sc.nextInt();
		switch(n) {
		case 1:{
				System.out.println("Enter Account Number: ");
				int acc_number=sc.nextInt();
				boolean b=as.checkAccountAvailable(acc_number);
				if(b==true) {
				while(true) {
					System.out.println("Enter Your Choice: \n1.Deposit Amount\n2.Withdrawal Amount\n3.Display\n4.Get Balance\n5.Fund Transfer");
					int choice=sc.nextInt();
					switch(choice){
					case 1:{
						//For Deposit
						System.out.println("You want to deposit amount in your account...\nEnter Account Number..");
						int account_Number_check=acc_number;
						System.out.println("Now enter the amount for deposit");
						int amount=sc.nextInt();
						int amountAfterDeposit=as.deposit(account_Number_check,amount);
						System.out.println("New Balance: "+amountAfterDeposit);
						break;
						}
					case 2:{
						//For Withdrawal
						System.out.println("You want to withdraw amount in your account...\nEnter Account Number..");
						int account_Number_check1=acc_number;
						System.out.println("Now enter the amount for Withdrawal");
						int amountWithdrawal=sc.nextInt();
						int amountAfterWithdraw=as.withdraw(account_Number_check1,amountWithdrawal);
						System.out.println("New Balance: "+amountAfterWithdraw);
						break;
						}
					case 3:{
						//For Display
						System.out.println("Accounts Detail: ");
						System.out.println(as.displayAccountDetails());
						break;
						}
					case 4:{
						//Get balance
						System.out.println("Enter your Account Number: ");
						int account_Number_Check=acc_number;
						int balance=as.getCurrentBalance(account_Number_Check);
						System.out.println("Current Balance: "+balance);
						break;
						}
					case 5:{
							//Fund Transfer
							int account_number,reciever_account_number,amount;
							System.out.println("Enter Account Number: ");
							account_number=acc_number;
							System.out.println("Enter Receiver Account Number: ");
							reciever_account_number=sc.nextInt();
							System.out.println("Enter Amount to Transfer: ");
							amount=sc.nextInt();
							String str=as.fundTransfer(account_number,reciever_account_number,amount);
							System.out.println(str);
							break;
						}
					//case 6:{
								//Print Transaction
						//		System.out.println("Enter The account Number For Print Transaction....");
							//	int account_number=sc.nextInt();
								
						//	}
					  }
				}
				}
				else {
					System.out.println("Account Number is not available..");
					}
				break;
				}
		case 2:{
				Account account=new Account();
				double account_number=Math.random();
				System.out.println("Add the following Account Detail for creating of new Account....");
				account.setAccount_Number(account_number);
				//h[i].setAccount_Number(account_number);
				System.out.println("Enter Account Holder Name: ");
				String account_HolderName=sc.next();
				account.setAccount_HolderName(account_HolderName);
				//h[i].setAccount_HolderName(account_HolderName);
				System.out.println("Enter five digit Phone Number: ");
				int phone_Number=sc.nextInt();
				account.setPhone_Number(phone_Number);
				System.out.println("Enter five digit Aadhar Number: ");
				int aadhar_Number=sc.nextInt();
				account.setAadhar_number(aadhar_Number);
				System.out.println("your account number is: "+account_number);
				LocalDateTime now=LocalDateTime.now();
				//h[i].setDate(now);
				as.addNewAccount(account);
				}
			}
		
		}
	}

}
