package com.cg.eis.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.eis.bean.Account;
import com.cg.eis.bean.History;
public class AccountDao {
static 	Map<Double,Account>account1=new HashMap<Double,Account>();
		Map<Double,History>history1=new HashMap<Double,History>();
		
		public boolean checkAccountAvailable(int acc) {
			for(Account o:account1.values()) {
				if(o.getAccount_Number()==acc) {
					return true;
				}
			}
			return false;
		}
		public void addHistory(History history) {
			history1.put(history.getAccount_Number(),history);
		}
	public Map<Double, Account> displayAccountDetails() {
		return account1;
	}
	public void addNewAccount(Account account) {
		 account1.put(account.getAccount_Number(),account);
	}

	public int deposit(int account_Number,int amount) {
		int amountAfterDeposit=0;
		for(Account o:account1.values()) {
			if(o!=null) {
			//System.out.println("account number:  "+ o.getAccount_Number());
			if(o.getAccount_Number()==account_Number) {
				amountAfterDeposit=o.getBalance()+amount;
				o.setBalance(amountAfterDeposit);
				break;
			}
			}
			else{
				System.out.println("Enter Proper Account Number..");
			}
		}
		return amountAfterDeposit;
	}

	public int withdraw(int account_Number_check1, int amountWithdrawal) {
		int amountAfterWithdraw=0;
		for(Account o:account1.values()) {
			if(o!=null) {
			if(o.getAccount_Number()==account_Number_check1) {
				 amountAfterWithdraw=o.getBalance()-amountWithdrawal;
				o.setBalance( amountAfterWithdraw);
				break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
			}
		}
		}
		return amountAfterWithdraw;
	}

	public int getCurrentBalance(int account_Number_Check2) {
		int displayBalance=0;
		for(Account o:account1.values()) {
			if(o!=null) {
			if(o.getAccount_Number()==account_Number_Check2) {
				 displayBalance=o.getBalance();
				// return displayBalance;
				 break;
			}
			else{
				System.out.println("Enter Proper Account Number..");
			}
			}
		}
		return displayBalance;
	}

	public String fundTransfer(int account_number, int reciever_account_number,int amountToTransfer) {
		int amountAfterWithdraw=0,cnt=0,cnt1=0;
		int amountAfterDeposit=0;
		for(Account o:account1.values()) {
			if(o!=null) {
			if(o.getAccount_Number()==account_number) {
				 amountAfterWithdraw=o.getBalance()-amountToTransfer;
				o.setBalance( amountAfterWithdraw);
				cnt++;
				break;
			}
			}
		}
		for(Account o:account1.values()) {
			if(o!=null) {
			if(o.getAccount_Number()==reciever_account_number) {
				amountAfterDeposit = o.getBalance()+amountToTransfer;
				o.setBalance(amountAfterDeposit);
				cnt1++;
				break;
			}
			}
		}
		if(cnt>0) {
			if(cnt1>0) {
				return "Transfered\n\n";
			}
			else 
				return "Check Recievers Account Number\n\n";
		}
		else
		return "Check your Account number\n\n";
	}
}

