package com.cg.eis.dao;

import java.util.Map;

import com.cg.eis.bean.Account;

public interface AccountDaoInterface {
	public Map<Double, Account> displayAccountDetails();
	public void addNewAccount(Account account);
}
